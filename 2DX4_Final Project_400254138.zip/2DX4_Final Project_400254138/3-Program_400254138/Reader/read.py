'''
Abhay Raina
400254138

Reads UART and stores the distance data in mm into x,y,z components in mm, in a .xyz file
running python 3.7.7
uses math and serial packages
'''
import serial
import math

# serialization initialization
portSerial = serial.Serial('COM6',115200) # Change COM Port #
portSerial.open
print("Port opened")


steps = 0 # rotational steps
xPos = 0 # x-coord in mm
deltaX = 380 # increment in x-dir, user changeable, please set in mm

# appendable file
f = open("C:/Users/abhay/Desktop/2DX4 Python/Visualizer/xyz_Data_400254138.xyz", "a")

#for sample track
count = 0
while count < 10: #change based on samples
    
    # reads in line 
    seed = portSerial.readline()
    
    # string conversion
    inp = seed.decode("utf-8")
    
    # carriage identifier removal and blank space removal in new line
    inp = inp[0:-2] 
    
    # checks if input is a digit, for checking if its all int based
    if (inp.isdigit() == True):
        
        angle = (float(steps/64.0))*2.0*math.pi # angle calc
        print("distance: " + inp + ", angle = " + str(angle))
        # int conversion       
        numeral = int(inp) 
        y = -numeral*math.cos(angle) # y-coords
        z = numeral*math.sin(angle) # z-coords
        
        # wrtite to file
        f.write('{} {} {}\n'.format(xPos,y,z))
        steps = steps + 1
        
    #reset    
    if steps == 64:
        steps = 0
        xPos = xPos + deltaX
        count+=1

# close port and file after finishing data reception
f.close()
print("Port Closed")
portSerial.close()