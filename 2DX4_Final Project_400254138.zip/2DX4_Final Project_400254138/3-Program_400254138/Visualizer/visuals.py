'''
Abhay Raina
400254138

Plots xyz file

running on python 3.7.7
uses open3d
uses numpy
'''
import open3d as o3d
import numpy as numpie


line_frame = []

# set to 10 for 10 data sets/planes. Used to create a wireframe in between points of same plane
pSameplane = 0
for i in range(10):
    for iterat in range(64):
        line_frame.append([iterat + pSameplane, iterat + pSameplane + 1])
    pSameplane += 64   

# sets the line segmentation for interplanar connections. Wireframing
pinitPlane = 0
lim = 64    
for j in range(9):
    for iterat in range(64):
        line_frame.append([iterat + pinitPlane, iterat + lim + pinitPlane])
    pinitPlane += 64

# reads the points cloud from xyz file in that formatting
pointCld = o3d.io.read_point_cloud("xyz_Data_400254138.xyz", format='xyz')

# appends the blank/square wireframe created and adjust its shape according to the coordinates passed from xyz file
line_model = o3d.geometry.LineSet(points=o3d.utility.Vector3dVector(numpie.asarray(pointCld.points)), lines=o3d.utility.Vector2iVector(line_frame))

# draw function
o3d.visualization.draw_geometries([line_model])